## Giao diện di động v1.3

Menu navy rõ hơn, nút chạm lớn, bố cục điện thoại. Gói GitHub có cổng PWA và trang mất mạng; nhập điểm thật mở trên Apps Script và cần mạng. Không cache hoặc đồng bộ điểm ngoại tuyến.

## Cập nhật v1.2

Xanh dương đậm hơn; logo THPT Hồ Thị Bi; tên Quản lý điểm kiểm tra; lưu/xác nhận từ một điểm; bỏ đối chiếu sĩ số; bỏ ký số; mẫu in 2 trang A4. Cập nhật cả Code.gs và Index.html, triển khai phiên bản mới. Không chạy lại setupSchool_, không xóa dữ liệu cũ.

# HTB — Quản lý điểm kiểm tra

Ứng dụng nhập điểm cho THPT Hồ Thị Bi. Bản 1.0, ngày 12/10/2026.

## Hai phiên bản trong gói

- `GoogleAppsScript/`: bản triển khai thật bằng tài khoản Google của trường. Tài khoản, phiếu điểm, phách, danh sách phòng, nhật ký lưu trong Google Sheets ở Google Drive. Ảnh chữ ký và bản chụp dữ liệu phiếu xác nhận lưu thành file riêng trong cùng thư mục.
- `WebXemThu/`: giao diện xem thử, chỉ lưu dữ liệu minh họa trong trình duyệt. Có thể mở index.html, hoặc đưa lên một web host tĩnh. Bản này KHÔNG ghi vào Google Drive, không dùng để nhập dữ liệu thật.

## Cài trên Google Drive — từng bước

1. Đăng nhập tài khoản Google của trường trên máy quản trị.
2. Mở https://script.google.com → **Dự án mới**. Đổi tên dự án thành **HTB - Quản lý điểm kiểm tra**.
3. Bấm tệp **Code.gs** bên trái → xóa nội dung mặc định → dán toàn bộ nội dung `GoogleAppsScript/Code.gs`.
4. Bên cạnh mục **Tệp**, bấm **+ → Tập lệnh (Script)** → đặt tên **Crypto** → dán toàn bộ `GoogleAppsScript/Crypto.gs`. Đây là thư viện mã hóa mật khẩu đã kèm trong gói.
5. Bấm **+ → HTML** → đặt tên chính xác **Index** (I viết hoa) → xóa nội dung mẫu → dán toàn bộ `GoogleAppsScript/Index.html`. File này đã gộp giao diện và thư viện đọc/ghi Excel; không phải thêm style.css hay app.js ở Apps Script.
6. Bấm biểu tượng **bánh răng — Cài đặt dự án (Project Settings)** ở thanh trái. Kéo xuống **Thuộc tính tập lệnh (Script properties)** → **Thêm thuộc tính tập lệnh**.
   - Property / Thuộc tính: `ADMIN_PHONE`
   - Value / Giá trị: số điện thoại quản trị của bạn, đủ 10 số, bắt đầu bằng 0. Ví dụ 0901234567 chỉ là ví dụ, hãy dùng số thật của quản trị trường.
   - Bấm **Lưu thuộc tính tập lệnh**.
7. Trở lại **Trình chỉnh sửa** (biểu tượng `<>`) → chọn hàm **setupSchool_** trên thanh công cụ → **Chạy (Run)** → cấp quyền Google Sheets và Drive cho dự án bạn vừa tạo. Không chia sẻ quyền chỉnh sửa dự án cho giáo viên.
8. Chỉ chạy `setupSchool_` **một lần**. Hàm này tự tạo thư mục **HTB - Quản lý điểm kiểm tra**, file cơ sở dữ liệu và tài khoản quản trị. Nếu báo đã thiết lập thì không chạy lại. Trong **Nhật ký thực thi**, có đường dẫn file dữ liệu.
9. Góc trên bên phải: **Triển khai (Deploy) → Bản triển khai mới (New deployment)**.
10. Bấm biểu tượng bánh răng cạnh loại triển khai → chọn **Ứng dụng web (Web app)**.
    - Mô tả: `HTB Quản lý điểm kiểm tra v1`.
    - **Thực thi dưới tên / Execute as: Tôi / Me** — tài khoản Google của trường.
    - **Ai có quyền truy cập / Who has access:** chọn **Bất kỳ ai / Anyone** nếu trường muốn đăng nhập chỉ bằng SĐT, không bắt đăng nhập Google. Nếu chính sách Workspace không cho tùy chọn này, cần quản trị Workspace cho phép hoặc sử dụng phạm vi tài khoản Google được trường cho phép. Không có cách bỏ qua chính sách của trường.
11. Bấm **Triển khai**, sao chép URL kết thúc bằng **/exec**. Đây mới là đường dẫn để giáo viên dùng chính thức. URL xem thử trên ChatGPT chỉ để duyệt giao diện.
12. Mở URL `/exec` → đăng nhập bằng SĐT đã khai báo trong `ADMIN_PHONE`, mật khẩu **Htb12345@** → đổi mật khẩu mới theo hướng dẫn.
13. Menu **Tài khoản giáo viên** → **Tải file mẫu** → thay dòng ví dụ bằng danh sách thật → **Chọn file Excel** → kiểm tra xem trước → **Xác nhận nhập**. Nhập tối đa 30 tài khoản/lần để hạn chế thời gian mã hóa; có thể chia danh sách lớn thành nhiều file.
14. Chọn **năm học, đợt kiểm tra**. Nhập **Quản lý số phách** và **Danh sách phòng thi**. Giáo viên có thể bắt đầu nhập điểm sau khi có số phách; không cần nhập đủ danh sách phòng thi để lưu/xác nhận điểm.
15. Gửi đường dẫn `/exec` và tài khoản cho giáo viên bằng kênh của trường. Giáo viên tự đổi mật khẩu lần đầu. Không gửi file cơ sở dữ liệu hoặc quyền sửa Apps Script cho giáo viên.

Khi cập nhật mã nguồn: dán file mới → lưu → **Triển khai → Quản lý các bản triển khai → Chỉnh sửa (bút chì) → Phiên bản mới → Triển khai**. Không chạy lại `setupSchool_`, không xóa Script properties.

## Mẫu Excel

Có nút **Tải file mẫu** ở từng menu, tạo file `.xlsx` có đúng tiêu đề. File mẫu có một dòng ví dụ; thay dòng đó bằng dữ liệu của trường trước khi nhập. Chỉ đọc sheet đầu tiên. Mỗi lần nhập phách/phòng tối đa 1.000 dòng và file tối đa 5 MB. File tài khoản tối đa 30 dòng.

### Tài khoản

| SĐT | Họ tên | Vai trò |
|---|---|---|
| 0901234567 | Nguyễn Văn A | teacher |

- Định dạng cột SĐT là **Text** trước khi nhập Excel để giữ số 0 đầu.
- Vai trò nhận `teacher` hoặc `admin`. Chỉ quản trị được nhập file và cấp vai trò.
- Tài khoản dùng chung các năm học, đợt kiểm tra; bộ lọc không tạo tài khoản riêng theo đợt.
- Không nhập mật khẩu trong Excel. Tài khoản mới dùng **Htb12345@**, bắt buộc đổi lần đầu.
- Tài khoản trùng SĐT bị từ chối, không tự ghi đè. Quản trị có chức năng khóa/mở và đặt lại mật khẩu.

### Số phách

| Khối | Môn | Phòng | Số phách |
|---|---|---|---|
| 10 | Toán | 01 | 10101 |

**Quy ước của phiên bản này:** một số phách định danh một túi bài/phiếu 50 dòng, ứng với một phòng trong cùng khối và môn. STT 1–50 là thứ tự bài trong túi. Nếu trường dùng một số phách riêng cho từng học sinh thì cần đổi cấu trúc ghép phách trước khi nhập thật.

- Giữ Phòng, Số phách dạng Text để bảo toàn số 0 đầu.
- Một phòng có một số phách cho mỗi khối + môn + năm học + đợt kiểm tra.
- Môn trong Excel phải trùng tên trong danh mục. Có thể thêm môn ở **Thiết lập & kết nối**.

### Phòng thi

| Khối | Môn | Phòng | STT | Mã học sinh | Họ tên | Lớp |
|---|---|---|---|---|---|---|
| 10 | Toán | 01 | 1 | HS001 | Nguyễn Văn A | 10A01 |

- STT phải khớp dòng nhập điểm; từ 1 đến 50, không trùng trong cùng phòng/môn.
- Mã học sinh không trùng trong cùng môn và đợt. Một học sinh được có các môn khác nhau.
- Lớp là thông tin cần thiết để xuất báo cáo theo lớp.
- Năm học và đợt lấy từ bộ lọc trên web. Kiểm tra bộ lọc trước khi bấm nhập.
- File chỉ thêm dòng mới, không ghi đè. Chưa có giao diện xóa/sửa danh sách đã nhập. Cần chuẩn bị và kiểm tra đúng danh sách trước khi nhập chính thức; nếu nhập nhầm, quản trị phải xử lý trên bản sao CSDL và kiểm tra liên kết trước khi chỉnh dữ liệu gốc. Không sửa STT khi đã nhập điểm.

## Nhập điểm và ký xác nhận

1. Giáo viên đăng nhập, đổi mật khẩu ở lần đầu. Đầu trang hiện họ tên từ tài khoản.
2. Chọn **Nhập điểm**, năm học, đợt, khối, môn, ngày kiểm tra và số phách.
3. Nếu muốn sửa phiếu cũ, chọn đúng phách rồi **Tải phiếu**, hoặc mở trong **Phiếu đã lưu**. Hệ thống không âm thầm ghi đè phiếu cũ.
4. Nhập điểm: `8.5` và `8,5` đều lưu số 8.5. Chấp nhận 0–10, tối đa 2 chữ số thập phân. Điểm 0 khác ô trống. Enter chuyển dòng tiếp; có thể dán cột điểm hoặc hai cột điểm + ghi chú từ Excel.
5. Nếu vắng/chưa có điểm, có thể để trống điểm và thêm ghi chú nếu cần. Không tự biến ô trống thành 0. Các dòng không có học sinh để trống.
6. **Lưu điểm** lưu bản nháp. **Lưu & xác nhận** chỉ yêu cầu ít nhất một điểm hợp lệ, sau đó khóa phiếu. Không kiểm tra số lượng học sinh, không bắt nhập đủ dòng, không chặn dòng ngoài danh sách phòng. Ảnh chữ ký PNG/JPG ≤200 KB là tùy chọn; nếu đã tải lên thì lưu cùng phiếu.
7. Phiếu chỉ được sửa bởi người sở hữu. Quản trị có thể xem và **Mở lại phiếu** có ghi lý do. Người chấm ban đầu tiếp tục sửa rồi xác nhận lại.
8. **In phiếu** dùng hộp thoại in trình duyệt; chọn **Lưu thành PDF** nếu cần file PDF. Dữ liệu chưa lưu vẫn có thể in, trạng thái Bản nháp hiện trên phiếu.

## Xác nhận và in phiếu

Đã bỏ chức năng ký số. Xác nhận bằng tài khoản giáo viên; lưu ảnh chữ ký nếu đã tải lên. Mẫu in A4 dọc chia 2 trang cố định, 25 dòng/trang, có logo và chữ ký mỗi trang. Khi in chọn A4, tỷ lệ 100%, tắt đầu trang/chân trang của trình duyệt. Ghi chú dài sử dụng cỡ chữ nhỏ hơn để giữ đủ nội dung.

## Báo cáo

Quản trị vào **Xem điểm & báo cáo**, chọn năm, đợt, khối, môn, lớp, phòng. Danh sách hiện ngay theo bộ lọc. **Xuất Excel** xuất chính dữ liệu đang lọc, gồm lớp, phòng, STT bài, mã học sinh, tên, phách, điểm dạng số, ghi chú, giám khảo và trạng thái bản nháp/đã xác nhận. Dòng chưa có điểm vẫn có mặt trong báo cáo. Điểm trung bình không tính ô trống, nhưng tính điểm 0.

Giáo viên xem phiếu của mình, không xem bảng ghép danh tính học sinh/phách. Quản trị xem tất cả phiếu và danh sách học sinh.

## Dữ liệu và bảo vệ tài khoản

- Google Sheets: Users, Records, Mappings, Roster, Audit. Không sửa JSON trực tiếp nếu chưa có bản sao và hiểu liên kết.
- Folder Drive và database tự tạo dưới quyền tài khoản trường, không công khai file.
- Mật khẩu băm PBKDF2-SHA256 100.000 vòng với salt riêng và pepper phía server; không lưu mật khẩu rõ trong database. CryptoJS 4.2.0 đã đi kèm.
- Phiên đăng nhập ở server, hết hạn tối đa 6 giờ và có thể kết thúc sớm do cache; làm mới trang cần đăng nhập lại. Khóa tài khoản/đặt lại mật khẩu vô hiệu hóa các phiên cũ.
- Sai đăng nhập 5 lần bị khóa thử lại 15 phút theo SĐT.
- Kiểm tra quyền tại server; không chỉ ẩn menu phía giao diện. ScriptLock và số phiên bản ngăn lưu chồng; server vẫn kiểm tra điểm, phách và danh sách.
- Tải báo cáo Excel xử lý chuỗi có tiền tố công thức để không thực thi dữ liệu nhập thành công thức.
- Sao lưu định kỳ cả thư mục Drive và các Script properties DB_ID, FOLDER_ID, PEPPER, CONFIG, ADMIN_PHONE bằng cơ chế quản trị của trường. Không công khai pepper. Bản này chưa có tác vụ sao lưu định kỳ tự động.
- Google Apps Script có giới hạn thời gian/quota; bản này dùng khóa toàn cục cho thao tác API. Chưa nghiệm thu tải nhiều giáo viên đồng thời, chưa có giới hạn môn chấm theo giáo viên, chưa có quy trình chấm hai vòng. Cần thử nghiệm với số lượng giáo viên của trường trước khi dùng chính thức.

## Kiểm tra đã thực hiện

- Kiểm tra cú pháp JavaScript.
- 18 kiểm tra backend với dịch vụ Google giả lập: xác thực, bắt buộc đổi mật khẩu, phân quyền, import, số 0 đầu, dấu chấm/phẩy, khóa phiếu, tranh chấp phiên bản, mở lại có lý do, hết hiệu lực phiên và giới hạn đăng nhập sai.
- 6 kiểm tra frontend/dữ liệu: điểm, import, khóa trùng, ghép báo cáo, escaping HTML, vòng đọc/ghi XLSX giữ đúng số điện thoại/phách/điểm dạng số.
- Kiểm tra thuật toán PBKDF2 đối chiếu với Node crypto.
- Chưa kiểm tra bằng trình duyệt tự động trong môi trường tạo bản này; chưa chạy trên tài khoản Google thực; chưa ký số USB thực; chưa thử tải đồng thời.

Chạy kiểm tra nguồn trong môi trường Node: `node tests/backend.test.cjs`, `node tests/frontend.test.cjs` (ở cây nguồn dự án có thư mục gas/ và dist/). Test không chứa thông tin thật của trường.

## Tài liệu tham khảo và thư viện

- Google Apps Script Web Apps: https://developers.google.com/apps-script/guides/web
- Giao tiếp giao diện/server và hàm riêng tư: https://developers.google.com/apps-script/guides/html/communication
- SheetJS CE 0.20.3, bản standalone đã kèm: https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js
- CryptoJS 4.2.0: https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.2.0/crypto-js.min.js
- Font Be Vietnam Pro qua Google Fonts; nếu không tải được, giao diện tự dùng font hệ thống.
