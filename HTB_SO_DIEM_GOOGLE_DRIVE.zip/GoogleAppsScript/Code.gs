/* HTB — Quản lý điểm kiểm tra. Run setupSchool_ from Apps Script editor once. */
const DEFAULT_PASSWORD_ = 'Htb12345@';
const SUBJECTS_ = ['Toán','Ngữ văn','Tiếng Anh','Vật lý','Hóa học','Sinh học','Lịch sử','Địa lý','GD Kinh tế và Pháp luật','Tin học','Công nghệ','GD Quốc phòng và An ninh','Giáo dục thể chất'];
function doGet(){return HtmlService.createHtmlOutputFromFile('Index').setTitle('HTB • Quản lý điểm kiểm tra').addMetaTag('viewport','width=device-width, initial-scale=1');}
function setupSchool_(){
 const p=PropertiesService.getScriptProperties();if(p.getProperty('DB_ID'))throw Error('Đã thiết lập. Không chạy lại.');
 const phone=phone_(p.getProperty('ADMIN_PHONE')||'');if(!/^0\d{9}$/.test(phone))throw Error('Thêm Script property ADMIN_PHONE: SĐT quản trị 10 chữ số.');
 const folder=DriveApp.createFolder('HTB - Quản lý điểm kiểm tra');const ss=SpreadsheetApp.create('HTB - Cơ sở dữ liệu điểm');DriveApp.getFileById(ss.getId()).moveTo(folder);
 ['Users','Records','Mappings','Roster','Audit'].forEach((name,i)=>{const s=i===0?ss.getSheets()[0].setName(name):ss.insertSheet(name);s.appendRow(['ID','JSON']);s.setFrozenRows(1);});
 p.setProperties({DB_ID:ss.getId(),FOLDER_ID:folder.getId(),PEPPER:Utilities.getUuid()+Utilities.getUuid(),CONFIG:JSON.stringify({years:['2026 - 2027'],periods:['Giữa HK1','HK1','Giữa HK2','HK2'],subjects:SUBJECTS_})});
 put_('Users',phone,{phone:phone,name:'Quản trị viên',role:'admin',active:true,mustChange:true,password:password_(DEFAULT_PASSWORD_)});
 console.log('Thiết lập xong. CSDL: '+ss.getUrl());
}
function db_(){const id=PropertiesService.getScriptProperties().getProperty('DB_ID');if(!id)throw Error('Chưa chạy setupSchool_.');return SpreadsheetApp.openById(id);}
function all_(name){const s=db_().getSheetByName(name);return s.getLastRow()<2?[]:s.getRange(2,1,s.getLastRow()-1,2).getValues().map(r=>JSON.parse(r[1]));}
function put_(name,id,value){const s=db_().getSheetByName(name);const match=s.getRange('A:A').createTextFinder(String(id)).matchEntireCell(true).findNext();const row=match?match.getRow():s.getLastRow()+1;s.getRange(row,1,1,2).setValues([[String(id),JSON.stringify(value)]]);}
function audit_(u,action,detail){const id=Utilities.getUuid();put_('Audit',id,{id,time:new Date().toISOString(),actor:u.phone,action,detail});}
function phone_(p){return String(p).trim().replace(/^\+84/,'0').replace(/[\s.-]/g,'');}
function hash_(s){return Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s));}
function password_(pass,salt){salt=salt||Utilities.getUuid();return {salt,iterations:100000,hash:CryptoJS.PBKDF2(pass+PropertiesService.getScriptProperties().getProperty('PEPPER'),salt,{keySize:8,iterations:100000,hasher:CryptoJS.algo.SHA256}).toString()};}
function equal_(a,b){let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0;}
function public_(u){return {phone:u.phone,name:u.name,role:u.role,mustChange:u.mustChange,active:u.active};}
function auth_(token){const raw=CacheService.getScriptCache().get('session:'+hash_(String(token||'')));if(!raw)throw Error('Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.');const s=JSON.parse(raw);const u=all_('Users').find(x=>x.phone===s.phone);if(!u||!u.active||s.rev!==(u.rev||0))throw Error('Tài khoản hoặc phiên không còn hiệu lực.');return u;}
function admin_(u){if(u.role!=='admin')throw Error('Chỉ quản trị viên có quyền thực hiện.');}
function scope_(p){const c=JSON.parse(PropertiesService.getScriptProperties().getProperty('CONFIG'));if(!c.years.includes(p.year)||!c.periods.includes(p.period))throw Error('Năm học hoặc đợt kiểm tra không hợp lệ.');}
function text_(v,max){const s=String(v??'').trim();if(!s||s.length>(max||100))throw Error('Thiếu dữ liệu hoặc dữ liệu quá dài.');return s;}
function key_(p){return [p.year,p.period,p.grade,p.subject,p.phach].join('|');}
function grade_(v){if(v===''||v===null||v===undefined)return null;const s=String(v).trim();if(!/^\d{1,2}([.,]\d{1,2})?$/.test(s))throw Error('Điểm phải là số 0–10, tối đa 2 chữ số thập phân.');const n=Number(s.replace(',','.'));if(n<0||n>10)throw Error('Điểm phải từ 0 đến 10.');return n;}
function api(action,p){p=p||{};const lock=LockService.getScriptLock();try{lock.waitLock(30000);return {ok:true,data:dispatch_(action,p)};}catch(e){return {ok:false,error:e.message||String(e)};}finally{if(lock.hasLock())lock.releaseLock();}}
function dispatch_(action,p){
 if(action==='login'){
 const phone=phone_(p.phone),props=PropertiesService.getScriptProperties(),k='attempt:'+hash_(phone);let a=JSON.parse(props.getProperty(k)||'{"count":0,"until":0}');if(a.until>Date.now()&&a.count>=5)throw Error('Sai mật khẩu nhiều lần. Thử lại sau 15 phút.');if(a.until<Date.now())a={count:0,until:Date.now()+900000};
 const u=all_('Users').find(x=>x.phone===phone);const valid=u&&u.active&&equal_(password_(String(p.password||''),u.password.salt).hash,u.password.hash);
 if(!valid){a.count++;props.setProperty(k,JSON.stringify(a));throw Error('SĐT hoặc mật khẩu không đúng.');}props.deleteProperty(k);
 const token=Utilities.getUuid()+Utilities.getUuid();CacheService.getScriptCache().put('session:'+hash_(token),JSON.stringify({phone,rev:u.rev||0}),21600);return {token,user:public_(u)};
 }
 const u=auth_(p.token);
 if(action==='logout'){CacheService.getScriptCache().remove('session:'+hash_(p.token));return true;}
 if(action==='changePassword'){
 if(!equal_(password_(String(p.oldPassword||''),u.password.salt).hash,u.password.hash))throw Error('Mật khẩu hiện tại không đúng.');const next=String(p.newPassword||'');if(next.length<10||next.length>128||!/[a-z]/.test(next)||!/[A-Z]/.test(next)||!/[0-9]/.test(next)||!/[\W_]/.test(next)||next===DEFAULT_PASSWORD_||next===p.oldPassword)throw Error('Mật khẩu mới cần 10–128 ký tự, có chữ hoa, chữ thường, số và ký tự đặc biệt.');
 u.password=password_(next);u.mustChange=false;u.rev=(u.rev||0)+1;put_('Users',u.phone,u);CacheService.getScriptCache().put('session:'+hash_(p.token),JSON.stringify({phone:u.phone,rev:u.rev}),21600);audit_(u,'Đổi mật khẩu',{});return public_(u);
 }
 if(u.mustChange)throw Error('Bạn cần đổi mật khẩu trước khi sử dụng.');
 if(action==='bootstrap')return {user:public_(u),config:JSON.parse(PropertiesService.getScriptProperties().getProperty('CONFIG')),connected:true};
 if(action==='addConfig'){admin_(u);if(!['years','periods','subjects'].includes(p.type))throw Error('Danh mục không hợp lệ.');const props=PropertiesService.getScriptProperties(),c=JSON.parse(props.getProperty('CONFIG')),v=text_(p.value,80);if(c[p.type].includes(v))throw Error('Mục này đã có.');c[p.type].push(v);props.setProperty('CONFIG',JSON.stringify(c));audit_(u,'Thêm danh mục',{type:p.type,value:v});return c;}
 if(action==='users'){admin_(u);return all_('Users').map(public_);}
 if(action==='setActive'){admin_(u);if(p.phone===u.phone)throw Error('Không thể khóa tài khoản đang dùng.');const v=all_('Users').find(x=>x.phone===p.phone);if(!v)throw Error('Không tìm thấy tài khoản.');v.active=!!p.active;v.rev=(v.rev||0)+1;put_('Users',v.phone,v);audit_(u,'Đổi trạng thái tài khoản',{phone:v.phone,active:v.active});return true;}
 if(action==='resetPassword'){admin_(u);if(p.phone===u.phone)throw Error('Hãy dùng chức năng đổi mật khẩu.');const v=all_('Users').find(x=>x.phone===p.phone);if(!v)throw Error('Không tìm thấy tài khoản.');v.password=password_(DEFAULT_PASSWORD_);v.mustChange=true;v.rev=(v.rev||0)+1;put_('Users',v.phone,v);audit_(u,'Đặt lại mật khẩu',{phone:v.phone});return true;}
 if(action==='import'){
 admin_(u);scope_(p);const rows=p.rows;if(!Array.isArray(rows)||!rows.length||rows.length>1000)throw Error('Mỗi lần nhập 1–1.000 dòng (tài khoản tối đa 30).');if(!['users','mappings','roster'].includes(p.kind))throw Error('Loại nhập không hợp lệ.');if(p.kind==='users'&&rows.length>30)throw Error('Chia tài khoản thành từng file tối đa 30 dòng.');
 const table={users:'Users',mappings:'Mappings',roster:'Roster'}[p.kind],existing=all_(table),seen=new Set();const data=rows.map((r,i)=>{
 try{
 let d,id;if(p.kind==='users'){const phone=phone_(r['SĐT']);if(!/^0\d{9}$/.test(phone))throw Error('SĐT phải đủ 10 số, bắt đầu bằng 0.');id=phone;if(existing.some(x=>x.phone===phone))throw Error('Tài khoản đã tồn tại.');d={phone,name:text_(r['Họ tên']),role:text_(r['Vai trò']),active:true,mustChange:true};if(!['teacher','admin'].includes(d.role))throw Error('Vai trò: teacher hoặc admin.');}
 else {d={year:p.year,period:p.period,grade:text_(r['Khối']),subject:text_(r['Môn']),room:text_(r['Phòng'])};if(!['10','11','12'].includes(d.grade))throw Error('Khối phải là 10, 11 hoặc 12.');const c=JSON.parse(PropertiesService.getScriptProperties().getProperty('CONFIG'));if(!c.subjects.includes(d.subject))throw Error('Môn chưa có trong danh mục.');
 if(p.kind==='mappings'){d.phach=text_(r['Số phách']);id=key_(d);if(existing.some(x=>x.year===d.year&&x.period===d.period&&x.grade===d.grade&&x.subject===d.subject&&x.room===d.room))throw Error('Phòng đã có số phách.');}
 else {d.stt=Number(r['STT']);if(!Number.isInteger(d.stt)||d.stt<1||d.stt>50)throw Error('STT phải từ 1–50.');d.studentId=text_(r['Mã học sinh']);d.name=text_(r['Họ tên']);d.className=text_(r['Lớp']);id=[d.year,d.period,d.grade,d.subject,d.room,d.stt].join('|');if(existing.some(x=>x.year===d.year&&x.period===d.period&&x.subject===d.subject&&x.studentId===d.studentId))throw Error('Học sinh đã được xếp môn này.');}
 if(existing.some(x=>x.id===id))throw Error('Dữ liệu đã tồn tại.');d.id=id;
 }
 if(seen.has(id))throw Error('Trùng khóa trong file.');seen.add(id);return {id,d};
 }catch(e){throw Error('Dòng '+(i+2)+': '+e.message);}
 });
 // Validate cross-row uniqueness before writing anything.
 if(p.kind!=='users'){const extra=new Set();data.forEach(({d})=>{const k=[d.year,d.period,d.grade,d.subject,p.kind==='mappings'?d.room:d.studentId].join('|');if(extra.has(k))throw Error('Trùng phòng hoặc học sinh trong file.');extra.add(k);});}
 const values=data.map(({id,d})=>{if(p.kind==='users')d.password=password_(DEFAULT_PASSWORD_);return [id,JSON.stringify(d)];});const sh=db_().getSheetByName(table);sh.getRange(sh.getLastRow()+1,1,values.length,2).setValues(values);audit_(u,'Nhập Excel',{kind:p.kind,count:data.length,year:p.year,period:p.period});return {count:data.length};
 }
 if(action==='list'){
 scope_(p);const records=all_('Records').filter(x=>x.year===p.year&&x.period===p.period&&(u.role==='admin'||x.owner===u.phone)).map(x=>{const d=Object.assign({},x);delete d.signatureId;return d;});
 const maps=all_('Mappings').filter(x=>x.year===p.year&&x.period===p.period);return {records,mappings:u.role==='admin'?maps:maps.map(x=>({grade:x.grade,subject:x.subject,phach:x.phach})),roster:u.role==='admin'?all_('Roster').filter(x=>x.year===p.year&&x.period===p.period):[]};
 }
 if(action==='loadRecord'){const r=all_('Records').find(x=>x.id===p.id);if(!r||(u.role!=='admin'&&r.owner!==u.phone))throw Error('Không có quyền xem phiếu.');const d=Object.assign({},r);if(d.signatureId){const b=DriveApp.getFileById(d.signatureId).getBlob();d.signature='data:'+b.getContentType()+';base64,'+Utilities.base64Encode(b.getBytes());}return d;}
 if(action==='saveRecord'){
 scope_(p);const c=JSON.parse(PropertiesService.getScriptProperties().getProperty('CONFIG'));if(!['10','11','12'].includes(p.grade)||!c.subjects.includes(p.subject))throw Error('Khối hoặc môn không hợp lệ.');p.phach=text_(p.phach);const map=all_('Mappings').find(x=>key_(x)===key_(p));if(!map)throw Error('Số phách chưa được quản trị viên khai báo cho khối và môn này.');if(!/^\d{4}-\d{2}-\d{2}$/.test(p.date)||isNaN(Date.parse(p.date)))throw Error('Chọn ngày kiểm tra hợp lệ.');
 const id=key_(p),old=all_('Records').find(x=>x.id===id);if(old&&old.owner!==u.phone)throw Error('Phiếu đã thuộc một giám khảo khác.');if(old&&old.status==='confirmed')throw Error('Phiếu đã xác nhận. Nhờ quản trị viên mở lại.');if(old&&(p.version||0)!==old.version)throw Error('Phiếu đã được cập nhật ở nơi khác. Hãy tải lại trước khi lưu.');
 if(!Array.isArray(p.rows)||p.rows.length!==50)throw Error('Phiếu phải có đúng 50 dòng.');const rows=p.rows.map((r,i)=>({stt:i+1,score:grade_(r.score),note:String(r.note||'').trim().slice(0,300)}));if(!rows.some(r=>r.score!==null))throw Error('Cần nhập ít nhất một điểm để lưu.');
 let signatureId=old?old.signatureId:null;const folder=DriveApp.getFolderById(PropertiesService.getScriptProperties().getProperty('FOLDER_ID'));if(p.signature){if(p.signature.length>280000||!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(p.signature))throw Error('Chữ ký phải là PNG/JPG, tối đa 200 KB.');const parts=p.signature.split(',');const bytes=Utilities.base64Decode(parts[1]);if(bytes.length>204800)throw Error('Ảnh chữ ký vượt 200 KB.');const hex=Array.from(bytes).slice(0,8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');if(!(hex.startsWith('89504e470d0a1a0a')||hex.startsWith('ffd8ff')))throw Error('Nội dung ảnh chữ ký không hợp lệ.');signatureId=folder.createFile(Utilities.newBlob(bytes,parts[0].slice(5,-7),'chu-ky-'+Utilities.getUuid())).getId();}
 const rec={id,year:p.year,period:p.period,grade:p.grade,subject:p.subject,phach:p.phach,room:map.room,date:p.date,owner:u.phone,teacher:u.name,rows,signatureId,status:p.confirm?'confirmed':'draft',version:(old?.version||0)+1,updatedAt:new Date().toISOString(),digitalSignature:false};
 if(p.confirm){const snapshot=folder.createFile('phieu-'+Utilities.getUuid()+'.json',JSON.stringify(rec),MimeType.PLAIN_TEXT);rec.snapshotId=snapshot.getId();}put_('Records',id,rec);audit_(u,p.confirm?'Xác nhận bằng chữ ký ảnh':'Lưu phiếu',{id,version:rec.version});return {id,version:rec.version,status:rec.status,updatedAt:rec.updatedAt};
 }
 if(action==='reopen'){admin_(u);const r=all_('Records').find(x=>x.id===p.id);if(!r)throw Error('Không tìm thấy phiếu.');const reason=text_(p.reason,300);r.status='draft';r.version++;put_('Records',r.id,r);audit_(u,'Mở lại phiếu',{id:r.id,reason});return true;}
 if(action==='audit'){admin_(u);return all_('Audit').slice(-200).reverse();}
 throw Error('Thao tác không được hỗ trợ.');
}
